import { Filters } from "./Filters";

export default function Header() {
  return (
    <header>
      <h1>Carrito de compras</h1>
      <h2>La tiendita</h2><br />
      <Filters />
    </header>
  );
}